
struct results
{
    int numSYN;
    int distinctIPs;
    int numARP;
    int blacklistTotal;
};

