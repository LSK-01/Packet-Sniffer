#include <stdint.h>

struct IPArray
{
  int IPSize;
  uint32_t *IPs;
  int i;
};